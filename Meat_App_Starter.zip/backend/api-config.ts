export const apiConfig = {
  secret: 'meat-api-password'
}

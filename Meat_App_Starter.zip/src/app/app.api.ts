import { environment } from '../environments/environment'

export const MEAT_API = environment.api

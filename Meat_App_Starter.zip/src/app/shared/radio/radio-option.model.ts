export class RadioOption {
  constructor(public label: string, public value: any){}
}

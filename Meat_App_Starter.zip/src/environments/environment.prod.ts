export const environment = {
  production: true,
  api: 'https://localhost'
};
